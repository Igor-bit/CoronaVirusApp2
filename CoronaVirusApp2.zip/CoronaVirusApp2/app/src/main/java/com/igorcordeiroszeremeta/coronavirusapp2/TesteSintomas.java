package com.igorcordeiroszeremeta.coronavirusapp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

public class TesteSintomas extends AppCompatActivity {

    int resultado = 0;
    private CheckBox febre;
    private CheckBox tosseSeca;
    private CheckBox cansaco;
    private CheckBox doresEDesconfortos;
    private CheckBox dorDeGarganta;
    private CheckBox diarreia;
    private CheckBox conjuntivite;
    private CheckBox dorDeCabeca;
    private CheckBox perdaDePaladarOuOlfato;
    private CheckBox erupcaoCutanea;
    private CheckBox dificuldadesParaRespirar;
    private CheckBox dorOuPressaoNoPeito;
    private CheckBox perdaDeFalaOuPerdaDeMovimento;

    private TextView textoDoResultadoFinal;
    private Button tratamento ,prevencao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teste);

        tratamento = findViewById(R.id.tratamento);

        prevencao = findViewById(R.id.prevencao);

        febre = findViewById(R.id.febre);

        tosseSeca = findViewById(R.id.tosseSeca);

        cansaco = findViewById(R.id.cansaco);

        doresEDesconfortos = findViewById(R.id.doresEDesconfortos);

        dorDeGarganta = findViewById(R.id.dorDeGarganta);

        diarreia = findViewById(R.id.diarreia);

        conjuntivite = findViewById(R.id.conjuntivite);

        dorDeCabeca = findViewById(R.id.dorDeCabeca);

        perdaDePaladarOuOlfato = findViewById(R.id.perdaDePaladarOuOlfato);

        erupcaoCutanea = findViewById(R.id.erupcaoCutanea);

        dificuldadesParaRespirar = findViewById(R.id.dificuldadesParaRespirar);

        dorOuPressaoNoPeito = findViewById(R.id.dorOuPressaoNoPeito);

        perdaDeFalaOuPerdaDeMovimento = findViewById(R.id.perdaDeFalaOuPerdaDeMovimento);

        textoDoResultadoFinal = findViewById(R.id.textoDoResultadoFinal);

    }

    public void conferirResultado(View v){

        if (febre.isChecked()) {
            resultado += 1;

        } else if (tosseSeca.isChecked()) {
            resultado += 1;

        } else if (cansaco.isChecked()) {
            resultado += 1;

        } else if (doresEDesconfortos.isChecked()) {
            resultado += 5;

        } else if (dorDeGarganta.isChecked()) {
            resultado += 5;

        } else if (diarreia.isChecked()) {
            resultado += 5;

        } else if (conjuntivite.isChecked()) {
            resultado += 5;

        } else if (dorDeCabeca.isChecked()) {
            resultado += 5;

        } else if (perdaDePaladarOuOlfato.isChecked()) {
            resultado += 5;

        } else if (erupcaoCutanea.isChecked()) {
            resultado += 5;

        } else if (dificuldadesParaRespirar.isChecked()) {
            resultado += 12;

        } else if (dorOuPressaoNoPeito.isChecked()) {
            resultado += 12;

        } else if (perdaDeFalaOuPerdaDeMovimento.isChecked()) {
            resultado += 12;
        }
        int resultadoDoTeste = resultado;

        if (resultadoDoTeste > 0 && resultadoDoTeste <= 3) {
            textoDoResultadoFinal.setText("Você apresenta os sintomas leves. Por favor, se cuide.");

        } else if (resultadoDoTeste > 4 && resultadoDoTeste < 12) {
            textoDoResultadoFinal.setText("Você apresenta os sintomas medianos. Por favor, tome cuidado. Em caso de piora, por favor, procure urgentemente uma unidade de saúde.");

        } else if(resultadoDoTeste >= 12 && resultadoDoTeste <= 35) {
            textoDoResultadoFinal.setText("Você apresenta os sintomas graves. Por favor, vá para uma unidade de saúde.");

        } else if (resultadoDoTeste > 35) {
            textoDoResultadoFinal.setText("Você apresenta os sintomas gravíssimos. Por favor, procure o mais rápido possível uma unidade de saúde.");
        }
    }

    public void tratamentos(View v){
        Intent it = new Intent(getApplicationContext(),Tratamentos.class);
        startActivity(it);

    }
    public void prevencao(View v){
        Intent it = new Intent(getApplicationContext(),Prevencao.class);
        startActivity(it);
    }
}